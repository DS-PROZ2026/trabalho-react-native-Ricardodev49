import React, { useState } from 'react';
import {View, Text, TouchableOpacity, ActivityIndicator, StyleSheet, Image, ScrollView} from 'react-native';

const QUIZ = [
  {
    id: 1,
    pergunta: 'O que significa "こんにちは" (Konnichiwa)?',
    imagem: 'https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcT6cZnlVpmhOWHe72iC7xo-Nj9Otf30d4qD9DccZOOmeQ&s=10',
    opcoes: ['Bom dia', 'Boa tarde / Olá', 'Boa noite', 'Até logo'],
    respostaCerta: 1
  },
  {
    id: 2,
    pergunta: 'Como se diz "Obrigado" em japonês?',
    imagem: 'https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcT6cZnlVpmhOWHe72iC7xo-Nj9Otf30d4qD9DccZOOmeQ&s=10',
    opcoes: ['Sumimasen', 'Sayonara', 'Arigatou', 'Ohayou'],
    respostaCerta: 2
  },
  {
    id: 3,
    pergunta: 'O que significa "さようなら" (Sayonara)?',
    imagem: 'https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcT6cZnlVpmhOWHe72iC7xo-Nj9Otf30d4qD9DccZOOmeQ&s=10',
    opcoes: ['Obrigado', 'Desculpe', 'Olá', 'Tchau'],
    respostaCerta: 3
  },
  {
    id: 4,
    pergunta: 'Qual é o número 3 em japonês?',
    imagem: 'https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcT6cZnlVpmhOWHe72iC7xo-Nj9Otf30d4qD9DccZOOmeQ&s=10',
    opcoes: ['Ichi', 'Ni', 'San', 'Yon'],
    respostaCerta: 2
  },
  {
    id: 5,
    pergunta: 'O que significa "水" (Mizu)?',
    imagem: 'https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcT6cZnlVpmhOWHe72iC7xo-Nj9Otf30d4qD9DccZOOmeQ&s=10',
    opcoes: ['Comida', 'Casa', 'Água', 'Escola'],
    respostaCerta: 2
  },
  {
    id: 6,
    pergunta: 'Como se diz "Bom dia" em japonês?',
    imagem: 'https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcT6cZnlVpmhOWHe72iC7xo-Nj9Otf30d4qD9DccZOOmeQ&s=10',
    opcoes: ['Ohayou', 'Konbanwa', 'Arigatou', 'Sayonara'],
    respostaCerta: 0
  },
  {
    id: 7,
    pergunta: 'O que significa "猫" (Neko)?',
    imagem: 'https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcT6cZnlVpmhOWHe72iC7xo-Nj9Otf30d4qD9DccZOOmeQ&s=10',
    opcoes: ['Cachorro', 'Pássaro', 'Peixe', 'Gato'],
    respostaCerta: 3
  },
  {
    id: 8,
    pergunta: 'Qual destas palavras significa "escola"?',
    imagem: 'https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcT6cZnlVpmhOWHe72iC7xo-Nj9Otf30d4qD9DccZOOmeQ&s=10',
    opcoes: ['Gakkou', 'Kuruma', 'Hon', 'Tomodachi'],
    respostaCerta: 0
  },
  {
    id: 9,
    pergunta: 'Como se diz "amigo" em japonês?',
    imagem: 'https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcT6cZnlVpmhOWHe72iC7xo-Nj9Otf30d4qD9DccZOOmeQ&s=10',
    opcoes: ['Tomodachi', 'Sensei', 'Kuruma', 'Neko'],
    respostaCerta: 0
  },
  {
    id: 10,
    pergunta: 'O que significa "先生" (Sensei)?',
    imagem: 'https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcT6cZnlVpmhOWHe72iC7xo-Nj9Otf30d4qD9DccZOOmeQ&s=10',
    opcoes: ['Aluno', 'Professor', 'Amigo', 'Médico'],
    respostaCerta: 1
  }
];

export default function App() {
  const [telaAtual, setTelaAtual] = useState('inicio');
  const [perguntaAtual, setPerguntaAtual] = useState(0);
  const [pontuacao, setPontuacao] = useState(0);
  const [carregando, setCarregando] = useState(false);

  const [respostaSelecionada, setRespostaSelecionada] = useState(null);
  const [botoesTravados, setBotoesTravados] = useState(false);

  function iniciarJogo() {
    setTelaAtual('quiz');
    setPerguntaAtual(0);
    setPontuacao(0);
    setRespostaSelecionada(null);
    setBotoesTravados(false);
  }

  function voltarAoInicio() {
    setTelaAtual('inicio');
  }

  function responder(indiceClicado) {
    if (botoesTravados) return;

    setRespostaSelecionada(indiceClicado);
    setBotoesTravados(true);

    const pergunta = QUIZ[perguntaAtual];

    setTimeout(() => {
      setCarregando(true);

      setTimeout(() => {
        if (indiceClicado === pergunta.respostaCerta) {
          setPontuacao((valorAtual) => valorAtual + 1);
        }

        if (perguntaAtual + 1 < QUIZ.length) {
          setPerguntaAtual((valorAtual) => valorAtual + 1);
          setRespostaSelecionada(null);
          setBotoesTravados(false);
        } else {
          setTelaAtual('resultado');
        }

        setCarregando(false);
      }, 1500);
    }, 1000);
  }

  if (telaAtual === 'inicio') {
    return (
      <View style={styles.telaCentrada}>
        <Image
          source={{
            uri: 'https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcT6cZnlVpmhOWHe72iC7xo-Nj9Otf30d4qD9DccZOOmeQ&s=10'
          }}
          style={styles.logoInicial}
        />

        <Text style={styles.tituloPrincipal}>
          Quiz Japonês/Nihongo
        </Text>

        <Text style={styles.subtituloInicio}>
          Teste seus conhecimentos!
        </Text>

        <TouchableOpacity
          style={styles.botaoIniciar}
          onPress={iniciarJogo}
        >
          <Text style={styles.textoBotaoIniciar}>
            INICIAR
          </Text>
        </TouchableOpacity>
      </View>
    );
  }

  if (telaAtual === 'resultado') {
    return (
      <View style={styles.telaCentrada}>
        <Text style={styles.titulo}>
          Fim de Jogo!
        </Text>

        <Text style={styles.subtitulo}>
          Você acertou {pontuacao} de {QUIZ.length}
        </Text>

        <TouchableOpacity
          style={styles.botaoAcao}
          onPress={voltarAoInicio}
        >
          <Text style={styles.textoBotaoAcao}>
            Voltar ao Início
          </Text>
        </TouchableOpacity>
      </View>
    );
  }

  if (carregando) {
    return (
      <View style={styles.telaCentrada}>
        <ActivityIndicator
          size="large"
          color="#3b82f6"
        />

        <Text style={styles.textoCarregando}>
          Validando resposta...
        </Text>
      </View>
    );
  }

  const pergunta = QUIZ[perguntaAtual];

  return (
    <ScrollView
      style={styles.tela}
      contentContainerStyle={{ paddingBottom: 30 }}
      showsVerticalScrollIndicator={false}
    >
      <View style={styles.cabecalho}>
        <Text style={styles.progresso}>
          Pergunta {perguntaAtual + 1} de {QUIZ.length}
        </Text>

        <Text style={styles.pontos}>
          Pontos: {pontuacao}
        </Text>
      </View>

      <View style={styles.cartaoPergunta}>
        <Image
          source={{ uri: pergunta.imagem }}
          style={styles.imagemPergunta}
        />

        <Text style={styles.textoPergunta}>
          {pergunta.pergunta}
        </Text>
      </View>

      <View style={styles.areaOpcoes}>
        {pergunta.opcoes.map((opcao, index) => {
          let corBotao = '#ffffff';

          if (
            respostaSelecionada !== null &&
            index === respostaSelecionada
          ) {
            corBotao =
              index === pergunta.respostaCerta
                ? '#22c55e'
                : '#ef4444';
          }

          return (
            <TouchableOpacity
              key={index}
              disabled={botoesTravados}
              style={[
                styles.botaoOpcao,
                { backgroundColor: corBotao }
              ]}
              onPress={() => responder(index)}
            >
              <Text style={styles.textoOpcao}>
                {opcao}
              </Text>
            </TouchableOpacity>
          );
        })}
      </View>
    </ScrollView>
  );
}

const styles = StyleSheet.create({
  tela: {
    flex: 1,
    backgroundColor: '#f8fafc',
    padding: 20,
    paddingTop: 60
  },

  telaCentrada: {
    flex: 1,
    backgroundColor: '#f8fafc',
    justifyContent: 'center',
    alignItems: 'center',
    padding: 20
  },

  logoInicial: {
    width: 120,
    height: 120,
    marginBottom: 20
  },

  tituloPrincipal: {
    fontSize: 32,
    fontWeight: 'bold',
    marginBottom: 10
  },

  subtituloInicio: {
    fontSize: 18,
    marginBottom: 40,
    textAlign: 'center'
  },

  botaoIniciar: {
    backgroundColor: '#10b981',
    padding: 20,
    borderRadius: 15
  },

  textoBotaoIniciar: {
    color: '#fff',
    fontWeight: 'bold',
    fontSize: 18
  },

  cabecalho: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    marginBottom: 20
  },

  progresso: {
    fontSize: 16,
    fontWeight: 'bold'
  },

  pontos: {
    fontSize: 16,
    fontWeight: 'bold'
  },

  cartaoPergunta: {
    backgroundColor: '#fff',
    borderRadius: 20,
    padding: 20,
    marginBottom: 20
  },

  imagemPergunta: {
    width: '100%',
    height: 180,
    borderRadius: 15,
    marginBottom: 20
  },

  textoPergunta: {
    fontSize: 22,
    fontWeight: 'bold',
    textAlign: 'center'
  },

  areaOpcoes: {
    marginBottom: 20
  },

  botaoOpcao: {
    padding: 18,
    borderRadius: 12,
    borderWidth: 2,
    borderColor: '#ddd',
    marginBottom: 12
  },

  textoOpcao: {
    textAlign: 'center',
    fontSize: 18,
    fontWeight: '600'
  },

  titulo: {
    fontSize: 30,
    fontWeight: 'bold',
    marginBottom: 20
  },

  subtitulo: {
    fontSize: 20,
    marginBottom: 30
  },

  botaoAcao: {
    backgroundColor: '#3b82f6',
    padding: 18,
    borderRadius: 15
  },

  textoBotaoAcao: {
    color: '#fff',
    fontWeight: 'bold'
  },

  textoCarregando: {
    marginTop: 20,
    fontSize: 18
  }
});